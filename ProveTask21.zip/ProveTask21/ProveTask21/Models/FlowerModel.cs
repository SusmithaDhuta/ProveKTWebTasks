﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProveTask21.Models
{
    public class FlowerClass
    {
        public int Id { get; set; }
        public string FlowerName { get; set; }
    }

}
