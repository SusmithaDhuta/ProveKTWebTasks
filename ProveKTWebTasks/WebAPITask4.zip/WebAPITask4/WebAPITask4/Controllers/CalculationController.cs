﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MyWebAPI.Controllers
{

    [Route("Calculation")]
    public class CalculationController : Controller
    {

        [Route("Add/{a}/{b}")]
        public string Add(int a, int b)
        {
            var c = (a + b);
           
            
             return $"the sum of two numbers is {c}";
            
        }

        [Route("Multiply/{a}/{b}")]
        public string  Multiply(int a, int b)
        {
            var c = a * b;
            return $"the sum of two numbers is {c}";
        }
    }
}

