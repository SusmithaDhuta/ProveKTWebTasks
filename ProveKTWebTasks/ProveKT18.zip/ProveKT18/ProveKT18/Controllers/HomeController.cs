﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using ProveKT18.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;


namespace ProveKT18.Controllers
{

    public class HomeController : Controller
    {

        public List<SelectListItem> GetAllItems()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem { Text = "Rose", Value = "1" });
            items.Add(new SelectListItem { Text = "Marigold", Value = "2" });
            items.Add(new SelectListItem { Text = "Tulip", Value = "3" });
            return items;
        }

        [HttpGet]
        public ActionResult Index()
        {

            var model = new ItemClass
            {
                //SelectedItemName = new[] {2},
                ItemList = GetAllItems()
            };

            return View(model);
        }
    }
}

 