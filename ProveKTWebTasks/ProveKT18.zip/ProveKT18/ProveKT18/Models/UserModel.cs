﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProveKT18.Models
{
    public class UserModel
    {
    }
}
