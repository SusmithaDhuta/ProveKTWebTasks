﻿using System.Net.Mail;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Aspose.Email;

namespace ProveTask26
{
    public class EmailProgram
    {
        static void Main(string[] args)
        {
            /*
            SmtpClient cv = new SmtpClient("smtp.live.com", 25);
            cv.EnableSsl = true;
            cv.Credentials = new NetworkCredential("susmitha2022@hotmail.com", "susmitha@2022");

            try
            {
                cv.Send("susmitha2022@hotmail.com", "susmitha2022@hotmail.com", "email subject","email body");
                Console.WriteLine("Email sent successfully");
            }
            catch(Exception ex)
            {
                Console.WriteLine("Email Can't sent successfully for below reasons:");
                Console.WriteLine(ex.Message);
            }
            */



            //try
            //{
            //    MailMessage message = new MailMessage();
            //    SmtpClient smtp = new SmtpClient();
            //    message.From = new MailAddress("susmitha.dhuta@gmail.com");
            //    message.To.Add(new MailAddress("susmithadhuta21@gmail.com"));
            //    message.Subject = "Test";
            //    message.IsBodyHtml = true; //to make message body as html  
            //    message.Body = "";
            //    smtp.Port = 587;
            //    smtp.Host = "smtp.gmail.com"; //for gmail host  
            //    smtp.EnableSsl = true;
            //    smtp.UseDefaultCredentials = false;
            //    smtp.Credentials = new NetworkCredential("susmitha.dhuta@gmail.com", "Vsusmitha@1996@");
            //    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            //    smtp.Send(message);
            //}
            //catch (Exception e)
            //{

            //    Console.WriteLine(e.Message);
            //}


            string suc_msg = "";
            System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
            msg.To.Add(new System.Net.Mail.MailAddress("susmithadhuta21@gmail.com", "Sush"));
            msg.From = new System.Net.Mail.MailAddress("susmitha.dhuta@gmail.com", "Sush");
            msg.Subject = "This is a Test Mail";
            msg.Body = "This is a test message using Exchange OnLine";
            msg.IsBodyHtml = true;

            SmtpClient client = new SmtpClient();
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("susmitha.dhuta@gmail.com", "Vsusmitha@1996@");
            client.Port = 587; // You can use Port 25 if 587 is blocked (mine is!)
            client.Host = "smtp.gmail.com";
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.EnableSsl = true;
            try
            {
                client.Send(msg);
                suc_msg = "Message Sent Succesfully";
            }
            catch (Exception ex)
            {
                suc_msg = ex.ToString();
            }
            Console.WriteLine(suc_msg);


        }
    }
}

